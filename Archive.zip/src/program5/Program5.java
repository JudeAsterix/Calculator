
package program5;

public class Program5 {
    public static void main(String[] args) {
        CalculatorFrame cf = new CalculatorFrame("Calculator");
        cf.setVisible(true);
    }
}
